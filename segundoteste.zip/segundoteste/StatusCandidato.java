package segundoteste;

public enum StatusCandidato {
  Recebido,
  Qualificado,
  Aprovado,
}
