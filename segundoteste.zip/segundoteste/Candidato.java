package segundoteste;

public class Candidato {
  public String nome;
  public int codCandidato;
  public StatusCandidato status;

  Candidato(String nome, int codCandidato, StatusCandidato status) {
    this.nome = nome;
    this.codCandidato = codCandidato;
    this.status = status;
  }
}
